// pages/confirm-login/index.js
Page({
  data: {
    scanId: '',
    loading: false,
  },

  onLoad(options) {
    if (options.scanId) {
      this.setData({
        scanId: options.scanId,
      });
    } else {
      wx.showToast({
        title: '参数错误',
        icon: 'none',
      });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    }
  },

  // 确认授权登录
  confirmLogin() {
    const { scanId, loading } = this.data;

    if (loading) return;

    console.log('[确认登录] 用户确认授权，scanId:', scanId);

    // 显示成功提示
    wx.showToast({
      title: '授权成功',
      icon: 'success',
      duration: 2000,
    });

    // 提示用户回到PC端
    setTimeout(() => {
      wx.showModal({
        title: '授权成功',
        content: '请返回电脑端继续操作',
        showCancel: false,
        confirmText: '知道了',
        success: () => {
          // 用户可以关闭小程序或返回
        },
      });
    }, 2000);
  },

  // 取消授权
  cancelLogin() {
    wx.showModal({
      title: '取消授权',
      content: '确定要取消此次登录吗？',
      confirmText: '确定',
      cancelText: '返回',
      success: (res) => {
        if (res.confirm) {
          wx.showToast({
            title: '已取消',
            icon: 'none',
          });
          // 可以调用后端取消接口，或者直接关闭
          setTimeout(() => {
            wx.navigateBack();
          }, 1500);
        }
      },
    });
  },
});

