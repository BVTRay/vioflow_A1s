// pages/scan/index.js - 扫码登录页面
const apiClient = require('../../utils/api');
const { api } = require('../../utils/api');

Page({
  data: {
    scanId: '',
    loading: false,
  },

  onLoad(options) {
    // 从扫码获取的参数
    // 小程序码会将 scene 参数传递进来，格式为 sid=xxx
    let scanId = options.scanId;
    
    // 如果没有直接的 scanId，尝试从 scene 中解析
    if (!scanId && options.scene) {
      const scene = decodeURIComponent(options.scene);
      console.log('Scene 参数:', scene);
      
      // 解析 scene 参数（格式为 sid=xxx）
      const matches = scene.match(/sid=([^&]+)/);
      if (matches && matches[1]) {
        scanId = matches[1];
      }
    }
    
    if (scanId) {
      this.setData({ scanId });
      this.handleScan(scanId);
    } else {
      wx.showToast({
        title: '缺少扫码参数',
        icon: 'none',
      });
      setTimeout(() => {
        wx.navigateBack();
      }, 2000);
    }
  },

  // 处理扫码
  async handleScan(scanId) {
    const { loading } = this.data;

    if (loading) {
      return;
    }

    this.setData({ loading: true });
    wx.showLoading({ title: '处理中...' });

    try {
      // 获取微信登录 code
      const loginRes = await new Promise((resolve, reject) => {
        wx.login({
          success: resolve,
          fail: reject,
        });
      });

      if (!loginRes.code) {
        throw new Error('获取微信登录凭证失败');
      }

      // 调用后端扫码接口
      await api.auth.scanQrCode(scanId, loginRes.code);

      wx.hideLoading();
      
      // 跳转到用户协议页面
      wx.redirectTo({
        url: `/pages/agreement/index?scanId=${scanId}&code=${loginRes.code}`,
      });
    } catch (error) {
      wx.hideLoading();
      this.setData({ loading: false });
      wx.showToast({
        title: error.message || '扫码失败',
        icon: 'none',
      });
      
      setTimeout(() => {
        wx.navigateBack();
      }, 2000);
    }
  },
});



